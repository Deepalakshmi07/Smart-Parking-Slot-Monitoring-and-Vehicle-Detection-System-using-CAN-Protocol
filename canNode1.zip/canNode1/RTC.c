#include <LPC21xx.h>
#include "types.h"
#include "i2c.h"
#include "i2c_eeprom.h"
#include "delay.h"
#include "i2c_defines.h"
#include "lcd2.h"
#include "rtc.h"

u8 min,sec,hr;

void set_time(void)
{

 i2c_eeprom_write(0x68,0x00,0x00);
 i2c_eeprom_write(0x68,0x01,0x05);
 i2c_eeprom_write(0x68,0x02,0x02);
}

//rtc main
void Display_Time(void)
{

   lcd_line4();
   str("Time : ");

hr=i2c_eeprom_read(0X68,0X02);

lcd_data((hr/16)+48);

lcd_data((hr%16)+48);

lcd_data(':');

min=i2c_eeprom_read(0X68,0X01);

lcd_data((min/16)+48);

lcd_data((min%16)+48);

lcd_data(':');

sec=i2c_eeprom_read(0X68,0X00);

lcd_data((sec/16)+48);

lcd_data((sec%16)+48);

}




