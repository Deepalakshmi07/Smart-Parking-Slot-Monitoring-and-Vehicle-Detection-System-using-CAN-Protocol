#include<LPC21XX.H>
#include "delay.h"
#include "lcd2.h"
#define LCD_D 0xF<<8
#define RS 1<<16
#define E 1<<17
/*
void lcd_init(void);
void lcd_cmd(unsigned char);
void lcd_data(unsigned char);
void str(unsigned char*);
void LCD_SCROLL(unsigned char *msg);
void lcd_line1(void);
void lcd_line2(void);
void lcd_line3(void);
void lcd_line4(void);
void lcd_gotoxy(unsigned char row,unsigned char col);

*/

/*int main()
{
LCD_INIT();
LCD_DATA('A');
} */

void lcd_init(void)
{
IODIR0|=LCD_D|RS|E;
lcd_cmd(0x01);
lcd_cmd(0x02);
lcd_cmd(0x0c);
lcd_cmd(0x28);
lcd_cmd(0x80);
}

void lcd_cmd(unsigned char cmd)
{
IOCLR0=LCD_D;
IOSET0=(cmd&0XF0)<<4;
IOCLR0=RS;
IOSET0=E;
delay_ms(2);
IOCLR0=E;

IOCLR0=LCD_D;
IOSET0=(cmd&0x0F)<<8;
IOCLR0=RS;
IOSET0=E;
delay_ms(2);
IOCLR0=E; 
} 

void lcd_data(unsigned char d)
{
IOCLR0=LCD_D;
IOSET0= (d&0xF0)<<4;
IOSET0=RS;
IOSET0=E;
delay_ms(2);
IOCLR0=E;

IOCLR0=LCD_D;
IOSET0=(d&0x0F)<<8;
IOSET0=RS;
IOSET0=E;
delay_ms(2);
IOCLR0=E; 
} 

void str(unsigned char*s)
{
  while(*s)
  {
    lcd_data(*s++);			 
  }
}


void LCD_SCROLL(unsigned char *str)
{
    unsigned int i,j,len=0;

    while(str[len]!='\0')
        len++;

    for(i=0;i<=len;i++)
    {
        lcd_line1();

        for(j=0;j<20;j++)
        {
            if(i+j<len)
                lcd_data(str[i+j]);
            else
                lcd_data(' ');
        }

        delay_ms(250);
    }
}

void lcd_line1(void)
{
    lcd_cmd(0x80);
}

void lcd_line2(void)
{
    lcd_cmd(0xC0);
}

void lcd_line3(void)
{
    lcd_cmd(0x94);
}

void lcd_line4(void)
{
    lcd_cmd(0xD4);
}


void lcd_gotoxy(unsigned char row,unsigned char col)
{
    switch(row)
    {
        case 1:
            lcd_cmd(0x80+col);
            break;

        case 2:
            lcd_cmd(0xC0+col);
            break;

        case 3:
            lcd_cmd(0x94+col);
            break;

        case 4:
            lcd_cmd(0xD4+col);
            break;
    }
}



