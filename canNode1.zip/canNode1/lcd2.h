
void lcd_init(void);
void lcd_cmd(unsigned char);
void lcd_data(unsigned char);
void str(unsigned char*);
void LCD_SCROLL(unsigned char *msg);
void lcd_line1(void);
void lcd_line2(void);
void lcd_line3(void);
void lcd_line4(void);
void lcd_gotoxy(unsigned char row,unsigned char col);
