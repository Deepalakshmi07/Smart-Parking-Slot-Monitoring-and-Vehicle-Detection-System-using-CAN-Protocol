#include <LPC21xx.h>
#include "types.h"
#include "delay.h"
#include "i2c.h"
#include "i2c_eeprom.h"
#include "i2c_defines.h"
#include "lcd2.h"
#include "rtc.h"
#include "canTx_driver.c"

#define TOTAL_SLOTS    6

CAN2_MSG rx;  
CAN2_MSG tx;

u8 occupied = 0;
u8 free_slots = TOTAL_SLOTS;

void Display_Waiting(void)
{
    lcd_cmd(0x01);
	delay_ms(2);

    lcd_line1();
    str("SMART PARKING SYS");

    lcd_line2();
    str("Waiting for Vehicle");
                                                                                                                                                                                                                                                                                                                                                                                                              
}

void Display_Entry(void)
{
    lcd_cmd(0x01);
    delay_ms(2);

    lcd_line1();
    str("SMART PARKING SYS");

    lcd_line2();
    str("Vehicle Entered");

    lcd_line3();
    str("Slot:");
    lcd_data(occupied+'0');
    lcd_data('/');
    lcd_data('6');
    str("  Free:");
    lcd_data(free_slots+'0');

    Display_Time();
}

void Display_Exit(void)
{
    lcd_cmd(0x01);
    delay_ms(2);

    lcd_line1();
    str("SMART PARKING SYS");

    lcd_line2();
    str("Vehicle Exited");

    lcd_line3();
    str("Slot:");
    lcd_data(occupied+'0');
    lcd_data('/');
    lcd_data('6');
    str("  Free:");
    lcd_data(free_slots+'0');

    Display_Time();
}

void Display_ParkingFull(void)
{
    lcd_cmd(0x01);
	delay_ms(2);

    lcd_line1();
    str("SMART PARKING SYS");

    lcd_line2();
    str("*** PARKING FULL ***");

    lcd_line3();
    str("Slot:6/6");
    str("  Free:0");

    Display_Time();
}

int main(void)
{

    lcd_init();
    init_i2c();
    set_time();
    can2_init();
    
    uart0_init(115200);

    uart0_tx_string("NODE1 READY\r\n");

    tx.rtr   = 0;
    tx.dlc   = 1;
    tx.byteB = 0x00;

    LCD_SCROLL("SMART PARKING SLOT MONITORING SYSTEM ");

    Display_Waiting();

    while(1)
    {
        
        can2_rx(&rx);
        if(rx.rtr==0)
        {
            uart0_tx_string("CAN FRAME RECEIVED\r\n");
            uart0_tx_hex(rx.id);
            uart0_tx(' ');
            uart0_tx_hex(rx.byteA);
            uart0_tx_string("\r\n");

            
            if((rx.id==0x201) && (rx.byteA==0x01))
            {
                if(occupied < TOTAL_SLOTS)
                {
                    occupied++;
                    free_slots = TOTAL_SLOTS - occupied;

                    Display_Entry();

                    
                    tx.id    = 0x301;
                    tx.byteA = 0x01;
                    can2_tx(tx);

                    uart0_tx_string("ENTRY SENT\r\n");

                    delay_ms(5000);

                    Display_Waiting();
                }
                else
                {
                    Display_ParkingFull();
                    uart0_tx_string("PARKING FULL\r\n");

                    delay_ms(5000);

                    Display_Waiting();
                }
            }

           
            if((rx.id==0x202) && (rx.byteA==0x02))
            {
                if(occupied>0)
                {
                    occupied--;
                    free_slots = TOTAL_SLOTS - occupied;
                }

                Display_Exit();
             
                tx.id    = 0x302;
                tx.byteA = 0x02;

                can2_tx(tx);

                uart0_tx_string("EXIT SENT\r\n");

                delay_ms(5000);

                Display_Waiting();
            }

        }

    }

}