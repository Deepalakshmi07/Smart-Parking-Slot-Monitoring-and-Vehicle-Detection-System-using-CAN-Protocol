#ifndef RTC_H
#define RTC_H

#include "types.h"

extern u8 hr;
extern u8 min;
extern u8 sec;

void set_time(void);
void Display_Time(void);

#endif