#include <LPC21xx.h>
#include "delay.h"
#include "can2_driver.c"
#define ENTRY_IR   (1<<14)      // P0.14
#define EXIT_IR    (1<<15)      // P0.15
#define LED1    (1<<16)
#define LED2    (1<<17)

CAN2_MSG tx;

void Port_Init(void)
{
    IODIR0 &= ~(ENTRY_IR | EXIT_IR);
	IODIR0 |=  LED1|LED2;
}
int main(void)
{
    Port_Init();

    can2_init();


    uart0_init(115200);


    uart0_tx_string("\r\nNODE2 READY\r\n");

    IOSET0 = LED1|LED2;

    tx.rtr = 0;          // Data Frame

    tx.dlc = 1;          // One Data Byte

    tx.byteB = 0x00;

    while(1)

    {

        //ENTRY 


        if((IOPIN0 & ENTRY_IR)==0)

        {
		    IOCLR0 = LED1;

            tx.id    = 0x201;

            tx.byteA = 0x01;

            can2_tx(tx);


            uart0_tx_string("ENTRY DETECTED\r\n");

            uart0_tx_string("CAN SENT : ");


            uart0_tx_hex(tx.id);

            uart0_tx(' ');

            uart0_tx_hex(tx.byteA);

            uart0_tx_string("\r\n");


            delay_ms(300);


            while((IOPIN0 & ENTRY_IR)==0);

			 IOSET0 = LED1;

        }
		



        //EXIT


        if((IOPIN0 & EXIT_IR)==0)

        {
		    IOCLR0 = LED2;

            tx.id    = 0x202;

            tx.byteA = 0x02;

            can2_tx(tx);

            uart0_tx_string("EXIT DETECTED\r\n");

            uart0_tx_string("CAN SENT : ");


            uart0_tx_hex(tx.id);

            uart0_tx(' ');

            uart0_tx_hex(tx.byteA);

            uart0_tx_string("\r\n");


            delay_ms(300);


            while((IOPIN0 & EXIT_IR)==0);

			 IOSET0 = LED2;

        }

    }

}