#include <LPC21xx.h>
#include "delay.h"
#include "can2_driver.c"

CAN2_MSG rx;

void Servo_Init(void)
{
    PINSEL0 |= 0x00000008;       

    VPBDIV = 1;                  

    PWMMR0 = (20000 * 60) - 1;   

    PWMMR3 = (1000 * 60) - 1;    

    PWMMCR = 0x02;               

    PWMPCR = 0x0800;            

    PWMTCR = 0x09;               

    PWMLER = 0x09;               
}


void Servo_0Deg(void)
{
    PWMMR3 = (1000 * 60) - 1;    

    PWMLER = (1 << 3);
}

void Servo_90Deg(void)
{
    PWMMR3 = (1500 * 60) - 1;    

    PWMLER = (1 << 3);
}


void gate(void)
{
    uart0_tx_string("Gate opening...\r\n");

    Servo_90Deg();

    delay_ms(3000);

    Servo_0Deg();

    uart0_tx_string("Gate closed\r\n");
}

int main(void)
{
    can2_init();

    Servo_Init();

    uart0_init(115200);

    Servo_0Deg();

    uart0_tx_string("\r\n");
    uart0_tx_string("NODE3 SERVO READY\r\n");
    uart0_tx_string("Waiting for CAN message...\r\n");


    while(1)
    {
        can2_rx(&rx);

        if(rx.rtr == 0)
        {
            uart0_tx_string("DATA FRAME RECEIVED\r\n");

            uart0_tx_string("RTR = ");
            uart0_tx_integer(rx.rtr);

            uart0_tx_string(" ID = ");
            uart0_tx_hex(rx.id);

            uart0_tx_string(" DLC = ");
            uart0_tx_hex(rx.dlc);

            uart0_tx_string(" DATA = ");
            uart0_tx_hex(rx.byteA);

            uart0_tx_string("\r\n");


            if((rx.id == 0x301) &&
               (rx.byteA == 0x01))
            {
                uart0_tx_string("ENTRY GATE COMMAND\r\n");

                gate();

                uart0_tx_string("ENTRY GATE CLOSED\r\n");
            }


            if((rx.id == 0x302) &&
               (rx.byteA == 0x02))
            {
                uart0_tx_string("EXIT GATE COMMAND\r\n");

                gate();

                uart0_tx_string("EXIT GATE CLOSED\r\n");
            }
        }


        else
        {
            uart0_tx_string("REMOTE FRAME RECEIVED\r\n");

            uart0_tx_string("ID = ");
            uart0_tx_hex(rx.id);

            uart0_tx_string("\r\n");
        }
    }
}